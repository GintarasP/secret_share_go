package indirect

import "dep"

func F(dep.Interface) {}
